import type { Screen } from '../types';

interface AuthScreenProps {
  mode: 'login' | 'register';
  onNavigate: (screen: Screen) => void;
}

export function AuthScreen({ mode, onNavigate }: AuthScreenProps) {
  const isLogin = mode === 'login';

  return (
    <div className="auth-page">
      <div className="auth-card">
        <h1 className="auth-logo">FoodFlow</h1>
        <div className="banner-ribbon">{isLogin ? 'ZALOGUJ SIĘ' : 'ZAREJESTRUJ SIĘ'}</div>

        <div className="form-stack">
          {!isLogin && <input className="soft-input" placeholder="Imię" />}
          {!isLogin && <input className="soft-input" placeholder="Nazwisko" />}
          <input className="soft-input" placeholder="Email" />
          <input className="soft-input" placeholder="Hasło" type="password" />
          {!isLogin && <input className="soft-input" placeholder="Powtórz hasło" type="password" />}
        </div>

        <button className="mint-button wide-button" onClick={() => onNavigate(isLogin ? 'home' : 'login')}>
          {isLogin ? 'ZALOGUJ SIĘ' : 'ZAREJESTRUJ SIĘ'}
        </button>

        <div className="auth-separator">lub</div>

        <button
          className="secondary-button wide-button"
          onClick={() => onNavigate(isLogin ? 'register' : 'login')}
        >
          {isLogin ? 'NIE MASZ KONTA? ZAREJESTRUJ SIĘ' : 'MASZ JUŻ KONTO? ZALOGUJ SIĘ'}
        </button>
      </div>
    </div>
  );
}
