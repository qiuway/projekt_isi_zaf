import { restaurants } from '../data/mockData';
import type { Screen } from '../types';
import { TopBar } from './TopBar';

interface HomeScreenProps {
  onNavigate: (screen: Screen) => void;
}

export function HomeScreen({ onNavigate }: HomeScreenProps) {
  const leftGroups = [restaurants.slice(0, 4), restaurants.slice(4, 8)];
  const rightGroups = [restaurants.slice(8, 12), restaurants.slice(12, 16)];

  return (
    <div className="page-shell">
      <TopBar onNavigate={onNavigate} />

      <div className="toolbar-row">
        <div className="filter-box yellow-box">Filtry:</div>
        <div className="filter-box orange-box"> Wyszukiwanie:</div>
        <div className="filter-box brown-box">Sortowanie:</div>
      </div>

      <div className="two-column-layout home-layout">
        <section className="column-panel divider-right">
          <div className="section-ribbon blue-ribbon home-ribbon">POLECANE I NOWOŚCI</div>
          <div className="restaurant-stack">
            {leftGroups.map((group, groupIndex) => (
              <article className="restaurant-card home-restaurant-panel" key={`left-${groupIndex}`}>
                <div className="restaurant-grid">
                  {group.map((restaurant) => (
                    <button
                      key={restaurant.id}
                      className="tile home-restaurant-tile"
                      onClick={() => onNavigate('restaurant')}
                    >
                      {restaurant.name}
                    </button>
                  ))}
                </div>
              </article>
            ))}
          </div>
        </section>

        <section className="column-panel">
          <div className="section-ribbon green-ribbon home-ribbon">SPECJALNE PROMOCJE</div>
          <div className="restaurant-stack">
            {rightGroups.map((group, groupIndex) => (
              <article className="restaurant-card home-restaurant-panel" key={`right-${groupIndex}`}>
                <div className="restaurant-grid">
                  {group.map((restaurant) => (
                    <button
                      key={restaurant.id}
                      className="tile home-restaurant-tile"
                      onClick={() => onNavigate('restaurant')}
                    >
                      {restaurant.name}
                    </button>
                  ))}
                </div>
              </article>
            ))}
          </div>
        </section>
      </div>
    </div>
  );
}
